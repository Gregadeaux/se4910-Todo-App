/** Automatically generated file. DO NOT MODIFY */
package com.msoe.deaux.se4910_lab2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}